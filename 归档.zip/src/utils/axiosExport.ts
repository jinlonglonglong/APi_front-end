import HttpRequest from './axiosSeal'
import {baseUrl} from '../config'
export default new HttpRequest(baseUrl)